package com.hazelgym.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.hazelgym.app.ui.screens.auth.LoginScreen
import com.hazelgym.app.ui.screens.client.ClientHomeScreen
import com.hazelgym.app.ui.screens.client.ClientRoutinesScreen
import com.hazelgym.app.ui.screens.trainer.TrainerHomeScreen
import com.hazelgym.app.ui.screens.trainer.TrainerSessionsScreen
import com.hazelgym.app.ui.screens.admin.AdminHomeScreen
import com.hazelgym.app.ui.screens.admin.AdminUsersScreen
import com.hazelgym.app.ui.screens.admin.AdminMachinesScreen
import com.hazelgym.app.ui.screens.admin.AdminQrScreen
import com.hazelgym.app.ui.screens.qr.QrScannerScreen
import com.hazelgym.app.ui.screens.qr.QrResultScreen
import com.hazelgym.app.ui.screens.machines.MachineDetailScreen

sealed class Screen(val route: String) {
    // Auth
    object Login : Screen("login")

    // Client
    object ClientHome    : Screen("client/home")
    object ClientRoutines: Screen("client/routines")

    // Trainer
    object TrainerHome    : Screen("trainer/home")
    object TrainerSessions: Screen("trainer/sessions")

    // Admin
    object AdminHome     : Screen("admin/home")
    object AdminUsers    : Screen("admin/users")
    object AdminMachines : Screen("admin/machines")
    object AdminQr       : Screen("admin/qr")

    // QR
    object QrScanner : Screen("qr/scanner")
    object QrResult  : Screen("qr/result/{type}/{id}") {
        fun withArgs(type: String, id: String) = "qr/result/$type/$id"
    }

    // Machines
    object MachineDetail : Screen("machine/{machineId}") {
        fun withArgs(machineId: String) = "machine/$machineId"
    }
}

@Composable
fun HazelNavGraph(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Screen.Login.route
    ) {
        // ── Auth ──────────────────────────────────────────────────
        composable(Screen.Login.route) {
            LoginScreen(navController)
        }

        // ── Cliente ───────────────────────────────────────────────
        composable(Screen.ClientHome.route) {
            ClientHomeScreen(navController)
        }
        composable(Screen.ClientRoutines.route) {
            ClientRoutinesScreen(navController)
        }

        // ── Entrenador ────────────────────────────────────────────
        composable(Screen.TrainerHome.route) {
            TrainerHomeScreen(navController)
        }
        composable(Screen.TrainerSessions.route) {
            TrainerSessionsScreen(navController)
        }

        // ── Admin ─────────────────────────────────────────────────
        composable(Screen.AdminHome.route) {
            AdminHomeScreen(navController)
        }
        composable(Screen.AdminUsers.route) {
            AdminUsersScreen(navController)
        }
        composable(Screen.AdminMachines.route) {
            AdminMachinesScreen(navController)
        }
        composable(Screen.AdminQr.route) {
            AdminQrScreen(navController)
        }

        // ── QR ────────────────────────────────────────────────────
        composable(Screen.QrScanner.route) {
            QrScannerScreen(navController)
        }
        composable(Screen.QrResult.route) { backStack ->
            val type = backStack.arguments?.getString("type") ?: ""
            val id   = backStack.arguments?.getString("id")   ?: ""
            QrResultScreen(navController, type, id)
        }

        // ── Máquinas ──────────────────────────────────────────────
        composable(Screen.MachineDetail.route) { backStack ->
            val machineId = backStack.arguments?.getString("machineId") ?: ""
            MachineDetailScreen(navController, machineId)
        }
    }
}
