package com.hazelgym.app.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.hazelgym.app.ui.navigation.Screen
import com.hazelgym.app.ui.theme.HazelDark
import com.hazelgym.app.ui.theme.HazelDarkSurface
import com.hazelgym.app.ui.theme.HazelOrange

@Composable
fun LoginScreen(navController: NavController) {
    var email    by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HazelDark)
            .padding(horizontal = 24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        // ── Logo / título ─────────────────────────────────────────
        Box(
            modifier = Modifier
                .size(52.dp)
                .background(HazelOrange, RoundedCornerShape(14.dp))
        )
        Spacer(Modifier.height(20.dp))

        Text(
            text  = "Bienvenido\nde vuelta",
            style = MaterialTheme.typography.displayLarge,
            color = Color.White
        )
        Text(
            text  = "Accede a Hazel Gym",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White.copy(alpha = 0.4f),
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(Modifier.height(32.dp))

        // ── Email ─────────────────────────────────────────────────
        OutlinedTextField(
            value         = email,
            onValueChange = { email = it },
            label         = { Text("Email") },
            singleLine    = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            modifier      = Modifier.fillMaxWidth(),
            shape         = RoundedCornerShape(12.dp),
            colors        = hazelTextFieldColors()
        )

        Spacer(Modifier.height(12.dp))

        // ── Contraseña ────────────────────────────────────────────
        OutlinedTextField(
            value               = password,
            onValueChange       = { password = it },
            label               = { Text("Contraseña") },
            singleLine          = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions     = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier            = Modifier.fillMaxWidth(),
            shape               = RoundedCornerShape(12.dp),
            colors              = hazelTextFieldColors()
        )

        Spacer(Modifier.height(24.dp))

        // ── Botón entrar ──────────────────────────────────────────
        Button(
            onClick = {
                isLoading = true
                // TODO: llamar a AuthViewModel.login(email, password)
                // Por ahora navegamos directo al home de cliente como demo
                navController.navigate(Screen.ClientHome.route) {
                    popUpTo(Screen.Login.route) { inclusive = true }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape  = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = HazelOrange),
            enabled = !isLoading
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    color    = Color.White,
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp
                )
            } else {
                Text("Entrar", style = MaterialTheme.typography.titleMedium)
            }
        }

        Spacer(Modifier.height(16.dp))

        TextButton(
            onClick  = { /* TODO: recuperar contraseña */ },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                "¿Olvidaste tu contraseña?",
                color     = Color.White.copy(alpha = 0.3f),
                textAlign = TextAlign.Center,
                style     = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

// ── Colores comunes para campos de texto ──────────────────────────────────────
@Composable
fun hazelTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor   = HazelOrange,
    unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
    focusedLabelColor    = HazelOrange,
    unfocusedLabelColor  = Color.White.copy(alpha = 0.4f),
    cursorColor          = HazelOrange,
    focusedTextColor     = Color.White,
    unfocusedTextColor   = Color.White,
    unfocusedContainerColor = HazelDarkSurface,
    focusedContainerColor   = HazelDarkSurface
)
