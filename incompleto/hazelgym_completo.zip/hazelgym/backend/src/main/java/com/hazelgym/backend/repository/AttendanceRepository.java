package com.hazelgym.backend.repository;

import com.hazelgym.backend.model.Attendance;
import com.hazelgym.backend.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, String> {

    // Total de visitas de un usuario
    long countByUser(User user);

    // Visitas de un usuario en un rango de fechas
    List<Attendance> findByUserAndDateTimeBetween(
        User user, LocalDateTime from, LocalDateTime to
    );

    // Comprobar si ya escaneó hoy (para evitar doble escaneo)
    @Query("""
        SELECT COUNT(a) > 0 FROM Attendance a
        WHERE a.user = :user
        AND a.dateTime >= :startOfDay
        AND a.dateTime < :endOfDay
        AND a.qrCode.gymEntry = true
    """)
    boolean hasCheckedInToday(
        @Param("user")       User user,
        @Param("startOfDay") LocalDateTime startOfDay,
        @Param("endOfDay")   LocalDateTime endOfDay
    );

    // Historial completo ordenado por fecha descendente
    List<Attendance> findByUserOrderByDateTimeDesc(User user);
}
