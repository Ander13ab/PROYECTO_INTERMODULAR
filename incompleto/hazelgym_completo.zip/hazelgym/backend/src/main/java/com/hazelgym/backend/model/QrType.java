package com.hazelgym.backend.model;

public enum QrType {
    ENTRY,          // Entrada al gimnasio
    MACHINE,        // Máquina específica
    CLASS_SESSION   // Sesión de clase (entrenador)
}
