package com.hazelgym.backend.repository;

import com.hazelgym.backend.model.QrCode;
import com.hazelgym.backend.model.QrType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface QrCodeRepository extends JpaRepository<QrCode, String> {

    Optional<QrCode> findByReferenceIdAndType(String referenceId, QrType type);

    Optional<QrCode> findFirstByGymEntryTrue();
}
