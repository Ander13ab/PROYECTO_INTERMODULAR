package com.hazelgym.backend.model;

public enum Role {
    CLIENT,
    TRAINER,
    ADMIN
}
