package com.hazelgym.backend.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "codigos_qr")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class QrCode {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private QrType type;

    // ID de la entidad relacionada: máquina o sesión de clase
    // null si es de entrada al gimnasio
    @Column(name = "reference_id")
    private String referenceId;

    @Column(name = "is_gym_entry")
    @Builder.Default
    private boolean gymEntry = false;
}
