package com.hazelgym.backend.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "maquinas")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Machine {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(nullable = false)
    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "muscle_group")
    private String muscleGroup;

    @Column(columnDefinition = "TEXT")
    private String instructions;

    private String tags;           // CSV: "Fuerza,Compuesto,Pectoral"

    @Column(name = "media_url")
    private String mediaUrl;

    @Builder.Default
    private String level = "Medio";

    @Column(name = "safety_warning", columnDefinition = "TEXT")
    private String safetyWarning;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private MachineStatus status = MachineStatus.ACTIVE;
}
