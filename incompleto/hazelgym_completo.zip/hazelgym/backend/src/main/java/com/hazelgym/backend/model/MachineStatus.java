package com.hazelgym.backend.model;

public enum MachineStatus {
    ACTIVE,
    OUT_OF_SERVICE
}
