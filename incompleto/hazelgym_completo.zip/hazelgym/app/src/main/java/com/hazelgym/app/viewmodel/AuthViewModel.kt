package com.hazelgym.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.hazelgym.app.data.local.TokenDataStore
import com.hazelgym.app.data.repository.AuthRepository
import com.hazelgym.app.data.repository.AuthRepositoryImpl
import com.hazelgym.app.model.User
import com.hazelgym.app.model.UserRole
import com.hazelgym.app.utils.Result
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

// ── UI State ──────────────────────────────────────────────────────────────────
sealed class AuthUiState {
    object Idle      : AuthUiState()
    object Loading   : AuthUiState()
    data class Success(val user: User) : AuthUiState()
    data class Error(val message: String) : AuthUiState()
    object LoggedOut : AuthUiState()
}

// ── ViewModel ─────────────────────────────────────────────────────────────────
class AuthViewModel(
    private val repository: AuthRepository,
    private val tokenDataStore: TokenDataStore
) : ViewModel() {

    private val _uiState = MutableStateFlow<AuthUiState>(AuthUiState.Idle)
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    // Usuario en memoria (una vez autenticado)
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    // ── Comprobar sesión activa al arrancar la app ─────────────────────────────
    init {
        checkExistingSession()
    }

    private fun checkExistingSession() {
        viewModelScope.launch {
            val token = tokenDataStore.getToken().first()
            if (!token.isNullOrBlank()) {
                // Hay token guardado → verificar que sigue siendo válido
                when (val result = repository.getCurrentUser()) {
                    is Result.Success -> {
                        _currentUser.value = result.data
                        _uiState.value = AuthUiState.Success(result.data)
                    }
                    is Result.Error -> {
                        // Token expirado o inválido → limpiar sesión silenciosamente
                        tokenDataStore.clearSession()
                        _uiState.value = AuthUiState.Idle
                    }
                    else -> Unit
                }
            }
        }
    }

    // ── Login ─────────────────────────────────────────────────────────────────
    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _uiState.value = AuthUiState.Error("Introduce email y contraseña")
            return
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            _uiState.value = AuthUiState.Error("El email no tiene un formato válido")
            return
        }

        viewModelScope.launch {
            _uiState.value = AuthUiState.Loading

            when (val result = repository.login(email.trim(), password)) {
                is Result.Success -> {
                    _currentUser.value = result.data
                    _uiState.value = AuthUiState.Success(result.data)
                }
                is Result.Error -> {
                    _uiState.value = AuthUiState.Error(result.message)
                }
                else -> Unit
            }
        }
    }

    // ── Logout ────────────────────────────────────────────────────────────────
    fun logout() {
        viewModelScope.launch {
            repository.logout()
            _currentUser.value = null
            _uiState.value = AuthUiState.LoggedOut
        }
    }

    // ── Reset de error (para limpiar el mensaje tras mostrarlo) ───────────────
    fun resetError() {
        if (_uiState.value is AuthUiState.Error) {
            _uiState.value = AuthUiState.Idle
        }
    }

    // ── Helper: destino de navegación según rol ───────────────────────────────
    fun homeRouteForRole(role: UserRole): String = when (role) {
        UserRole.CLIENT  -> "client/home"
        UserRole.TRAINER -> "trainer/home"
        UserRole.ADMIN   -> "admin/home"
    }

    // ── Factory ───────────────────────────────────────────────────────────────
    class Factory(
        private val tokenDataStore: TokenDataStore
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val repository = AuthRepositoryImpl(tokenDataStore)
            return AuthViewModel(repository, tokenDataStore) as T
        }
    }
}
