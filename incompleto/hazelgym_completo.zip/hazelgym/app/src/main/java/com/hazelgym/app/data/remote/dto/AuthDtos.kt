package com.hazelgym.app.data.remote.dto

import com.google.gson.annotations.SerializedName

// ── Request ───────────────────────────────────────────────────────────────────
data class LoginRequest(
    @SerializedName("email")    val email   : String,
    @SerializedName("password") val password: String
)

// ── Response ──────────────────────────────────────────────────────────────────
data class LoginResponse(
    @SerializedName("token")     val token    : String,
    @SerializedName("tokenType") val tokenType: String = "Bearer",
    @SerializedName("user")      val user     : UserDto
)

data class UserDto(
    @SerializedName("id")    val id   : String,
    @SerializedName("name")  val name : String,
    @SerializedName("email") val email: String,
    @SerializedName("role")  val role : String   // "CLIENT" | "TRAINER" | "ADMIN"
)

// ── Wrapper genérico de respuesta API ─────────────────────────────────────────
// Útil si tu Spring Boot envuelve las respuestas en { data: ..., message: ... }
data class ApiResponse<T>(
    @SerializedName("data")    val data   : T?,
    @SerializedName("message") val message: String? = null,
    @SerializedName("success") val success: Boolean = true
)
