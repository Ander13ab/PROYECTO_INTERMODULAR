package com.hazelgym.app.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.hazelgym.app.data.local.TokenDataStore
import com.hazelgym.app.ui.navigation.Screen
import com.hazelgym.app.ui.theme.*
import com.hazelgym.app.viewmodel.AuthUiState
import com.hazelgym.app.viewmodel.AuthViewModel

@Composable
fun LoginScreen(navController: NavController) {
    val context = LocalContext.current
    val tokenDataStore = remember { TokenDataStore(context) }
    val viewModel: AuthViewModel = viewModel(
        factory = AuthViewModel.Factory(tokenDataStore)
    )

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    var email           by remember { mutableStateOf("") }
    var password        by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var errorMsg        by remember { mutableStateOf<String?>(null) }

    // ── Reaccionar a cambios de estado ────────────────────────────────────────
    LaunchedEffect(uiState) {
        when (val state = uiState) {
            is AuthUiState.Success -> {
                val route = viewModel.homeRouteForRole(state.user.role)
                navController.navigate(route) {
                    popUpTo(Screen.Login.route) { inclusive = true }
                }
            }
            is AuthUiState.Error -> {
                errorMsg = state.message
            }
            else -> Unit
        }
    }

    val isLoading = uiState is AuthUiState.Loading

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HazelDark)
            .padding(horizontal = 28.dp),
        verticalArrangement = Arrangement.Center
    ) {
        // ── Logo ──────────────────────────────────────────────────
        Box(
            modifier = Modifier
                .size(52.dp)
                .background(HazelOrange, RoundedCornerShape(14.dp))
        )
        Spacer(Modifier.height(22.dp))

        Text(
            text  = "Bienvenido\nde vuelta",
            style = MaterialTheme.typography.displayLarge,
            color = Color.White
        )
        Text(
            text     = "Accede a Hazel Gym",
            style    = MaterialTheme.typography.bodyMedium,
            color    = Color.White.copy(alpha = 0.4f),
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(Modifier.height(36.dp))

        // ── Email ─────────────────────────────────────────────────
        OutlinedTextField(
            value         = email,
            onValueChange = {
                email    = it
                errorMsg = null
                viewModel.resetError()
            },
            label           = { Text("Email") },
            singleLine      = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            modifier        = Modifier.fillMaxWidth(),
            shape           = RoundedCornerShape(12.dp),
            colors          = hazelTextFieldColors(),
            enabled         = !isLoading
        )

        Spacer(Modifier.height(12.dp))

        // ── Contraseña ────────────────────────────────────────────
        OutlinedTextField(
            value                = password,
            onValueChange        = {
                password = it
                errorMsg = null
                viewModel.resetError()
            },
            label                = { Text("Contraseña") },
            singleLine           = true,
            visualTransformation = if (passwordVisible)
                VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions      = KeyboardOptions(keyboardType = KeyboardType.Password),
            trailingIcon         = {
                TextButton(onClick = { passwordVisible = !passwordVisible }) {
                    Text(
                        if (passwordVisible) "Ocultar" else "Ver",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(0.4f)
                    )
                }
            },
            modifier = Modifier.fillMaxWidth(),
            shape    = RoundedCornerShape(12.dp),
            colors   = hazelTextFieldColors(),
            enabled  = !isLoading
        )

        // ── Mensaje de error ──────────────────────────────────────
        if (!errorMsg.isNullOrBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(
                text     = errorMsg!!,
                color    = HazelError,
                style    = MaterialTheme.typography.bodyMedium,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(HazelError.copy(0.08f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }

        Spacer(Modifier.height(24.dp))

        // ── Botón entrar ──────────────────────────────────────────
        Button(
            onClick  = { viewModel.login(email, password) },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape    = RoundedCornerShape(12.dp),
            colors   = ButtonDefaults.buttonColors(containerColor = HazelOrange),
            enabled  = !isLoading
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    color       = Color.White,
                    modifier    = Modifier.size(22.dp),
                    strokeWidth = 2.dp
                )
            } else {
                Text("Entrar", style = MaterialTheme.typography.titleMedium)
            }
        }

        Spacer(Modifier.height(12.dp))

        TextButton(
            onClick  = { /* TODO: pantalla recuperar contraseña */ },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                "¿Olvidaste tu contraseña?",
                color     = Color.White.copy(alpha = 0.3f),
                textAlign = TextAlign.Center,
                style     = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

// ── Colores reutilizables para campos de texto ────────────────────────────────
@Composable
fun hazelTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor      = HazelOrange,
    unfocusedBorderColor    = Color.White.copy(alpha = 0.15f),
    focusedLabelColor       = HazelOrange,
    unfocusedLabelColor     = Color.White.copy(alpha = 0.4f),
    cursorColor             = HazelOrange,
    focusedTextColor        = Color.White,
    unfocusedTextColor      = Color.White,
    unfocusedContainerColor = HazelDarkSurface,
    focusedContainerColor   = HazelDarkSurface,
    errorBorderColor        = HazelError,
    errorLabelColor         = HazelError
)
