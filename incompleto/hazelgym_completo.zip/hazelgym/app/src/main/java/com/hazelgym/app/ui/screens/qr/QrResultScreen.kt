package com.hazelgym.app.ui.screens.qr

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.hazelgym.app.ui.navigation.Screen
import com.hazelgym.app.ui.theme.*

@Composable
fun QrResultScreen(
    navController: NavController,
    type: String,
    id  : String
) {
    when (type) {
        "entry"   -> EntrySuccessContent(navController)
        "machine" -> MachineInfoContent(navController, id)
        "class"   -> ClassCheckinContent(navController)
        else      -> QrErrorContent(navController, "Tipo de QR desconocido")
    }
}

// ── 1. Éxito — entrada ────────────────────────────────────────────────────────
@Composable
private fun EntrySuccessContent(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A1A0E))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        SuccessCircle(color = HazelGreen)
        Spacer(Modifier.height(14.dp))

        Text("¡Entrada registrada!", style = MaterialTheme.typography.headlineMedium, color = Color.White)
        Text("Bienvenido a Hazel Gym",
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White.copy(0.4f),
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
        )

        // Tarjeta de datos
        Surface(
            shape  = RoundedCornerShape(14.dp),
            color  = Color(0xFF1A2E1E),
            border = androidx.compose.foundation.BorderStroke(0.5.dp, HazelGreen.copy(0.2f))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                ResultRow("Usuario",  "Carlos M.")
                ResultRow("Hora",     "09:41")
                ResultRow("Fecha",    "20 abr 2026")
                ResultRow("Visita nº","48", valueColor = HazelGreen)
            }
        }

        Spacer(Modifier.height(12.dp))

        // Racha
        Surface(shape = RoundedCornerShape(20.dp), color = HazelOrange.copy(0.15f)) {
            Text(
                "🔥  Racha: 15 días seguidos",
                style    = MaterialTheme.typography.labelSmall,
                color    = HazelOrange,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
            )
        }

        Spacer(Modifier.height(24.dp))

        Button(
            onClick = { navController.navigate(Screen.ClientHome.route) {
                popUpTo(Screen.QrScanner.route) { inclusive = true }
            }},
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape    = RoundedCornerShape(12.dp),
            colors   = ButtonDefaults.buttonColors(containerColor = HazelGreen)
        ) {
            Text("Volver al inicio", color = Color(0xFF0A1A0E),
                style = MaterialTheme.typography.titleMedium)
        }
    }
}

// ── 2. Info máquina ───────────────────────────────────────────────────────────
@Composable
private fun MachineInfoContent(navController: NavController, machineId: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HazelDark)
            .padding(16.dp)
    ) {
        Text("Press banca",      style = MaterialTheme.typography.headlineMedium, color = Color.White)
        Text("Pectoral · Tríceps",style = MaterialTheme.typography.bodyMedium, color = HazelBlue,
            modifier = Modifier.padding(top = 2.dp, bottom = 12.dp))

        // Imagen placeholder
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .background(HazelDarkSurface, RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("Imagen / vídeo", color = Color.White.copy(0.2f), style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(Modifier.height(12.dp))

        // Pasos
        Text("INSTRUCCIONES", style = MaterialTheme.typography.labelSmall,
            color = Color.White.copy(0.35f))
        Spacer(Modifier.height(8.dp))

        listOf(
            "Ajusta el banco a posición horizontal y selecciona el peso.",
            "Agarre a la anchura de hombros, codos a 45°.",
            "Baja controlado hasta el pecho, empuja sin bloquear codos."
        ).forEachIndexed { i, step ->
            Row(modifier = Modifier.padding(bottom = 8.dp)) {
                Box(
                    Modifier.size(20.dp).background(HazelBlue, RoundedCornerShape(5.dp)),
                    contentAlignment = Alignment.Center
                ) { Text("${i+1}", style = MaterialTheme.typography.labelSmall, color = Color.White) }
                Spacer(Modifier.width(8.dp))
                Text(step, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(0.6f))
            }
        }

        Spacer(Modifier.height(12.dp))

        // Aviso seguridad
        Surface(
            shape  = RoundedCornerShape(10.dp),
            color  = HazelError.copy(0.08f),
            border = androidx.compose.foundation.BorderStroke(0.5.dp, HazelError.copy(0.2f))
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text("Aviso de seguridad", style = MaterialTheme.typography.labelSmall, color = HazelError.copy(0.7f))
                Spacer(Modifier.height(4.dp))
                Text("No uses cargas elevadas sin un compañero.",
                    style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(0.4f))
            }
        }

        Spacer(Modifier.height(16.dp))
        TextButton(onClick = { navController.popBackStack() }) {
            Text("← Volver", color = Color.White.copy(0.4f))
        }
    }
}

// ── 3. Check-in clase ─────────────────────────────────────────────────────────
@Composable
private fun ClassCheckinContent(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0F20))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        SuccessCircle(color = HazelBlue)
        Spacer(Modifier.height(14.dp))

        Text("Clase registrada", style = MaterialTheme.typography.headlineMedium, color = Color.White)
        Text("Sesión confirmada correctamente",
            style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(0.35f),
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))

        Surface(
            shape  = RoundedCornerShape(14.dp),
            color  = Color(0xFF1A2040),
            border = androidx.compose.foundation.BorderStroke(0.5.dp, HazelBlue.copy(0.2f))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                ResultRow("Clase",      "Spinning")
                ResultRow("Entrenador", "Laura R.")
                ResultRow("Inicio",     "08:30")
                ResultRow("Duración",   "50 min")
            }
        }

        Spacer(Modifier.height(10.dp))

        // Progreso mensual
        Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFF1A2040)) {
            Column(modifier = Modifier.padding(12.dp).fillMaxWidth()) {
                Text("Clases este mes", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(0.4f))
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { 22f / 30f },
                    modifier = Modifier.fillMaxWidth().height(6.dp),
                    color     = HazelBlue,
                    trackColor = Color(0xFF0A0F20)
                )
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                    Text("22 impartidas", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(0.3f))
                    Text("objetivo: 30",  style = MaterialTheme.typography.labelSmall, color = Color.White.copy(0.3f))
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        Button(
            onClick = { navController.navigate(Screen.TrainerHome.route) {
                popUpTo(Screen.QrScanner.route) { inclusive = true }
            }},
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape    = RoundedCornerShape(12.dp),
            colors   = ButtonDefaults.buttonColors(containerColor = HazelBlue)
        ) {
            Text("Ver agenda del día", style = MaterialTheme.typography.titleMedium)
        }
    }
}

// ── 4. Error ──────────────────────────────────────────────────────────────────
@Composable
fun QrErrorContent(navController: NavController, reason: String = "") {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF160A0A))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .background(HazelError.copy(0.15f), RoundedCornerShape(30.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("✕", style = MaterialTheme.typography.headlineMedium, color = HazelError)
        }
        Spacer(Modifier.height(14.dp))

        Text("QR no válido", style = MaterialTheme.typography.headlineMedium, color = Color.White)
        Text("No se pudo completar el registro",
            style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(0.35f),
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))

        Surface(
            shape  = RoundedCornerShape(12.dp),
            color  = Color(0xFF1C1010),
            border = androidx.compose.foundation.BorderStroke(0.5.dp, HazelError.copy(0.15f))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Posibles causas", style = MaterialTheme.typography.labelSmall, color = HazelError.copy(0.6f))
                Spacer(Modifier.height(6.dp))
                listOf(
                    "QR caducado o ya usado hoy",
                    "El QR no pertenece a esta sede",
                    "Sin conexión al servidor",
                    "Cuenta inactiva o suspendida"
                ).forEach {
                    Text("· $it", style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(0.4f),
                        modifier = Modifier.padding(vertical = 2.dp))
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        Button(
            onClick = { navController.popBackStack() },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape    = RoundedCornerShape(12.dp),
            colors   = ButtonDefaults.buttonColors(containerColor = HazelError)
        ) {
            Text("Intentar de nuevo", style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick  = { navController.navigate(Screen.ClientHome.route) },
            modifier = Modifier.fillMaxWidth().height(44.dp),
            shape    = RoundedCornerShape(12.dp)
        ) {
            Text("Volver al inicio", color = Color.White.copy(0.4f))
        }
    }
}

// ── Helpers ───────────────────────────────────────────────────────────────────
@Composable
private fun SuccessCircle(color: Color) {
    Box(
        modifier = Modifier
            .size(62.dp)
            .background(color.copy(0.15f), RoundedCornerShape(31.dp))
            .then(
                Modifier.background(Color.Transparent)
            ),
        contentAlignment = Alignment.Center
    ) {
        Text("✓", style = MaterialTheme.typography.headlineMedium, color = color)
    }
}

@Composable
private fun ResultRow(label: String, value: String, valueColor: Color = Color.White) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(0.4f))
        Text(value, style = MaterialTheme.typography.bodyMedium, color = valueColor)
    }
}
