package com.hazelgym.app.ui.screens.client

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.hazelgym.app.ui.navigation.Screen
import com.hazelgym.app.ui.theme.*

@Composable
fun ClientHomeScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F4F0))
    ) {
        // ── Header ────────────────────────────────────────────────
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(HazelDark, RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp))
                .padding(horizontal = 20.dp, vertical = 20.dp)
        ) {
            Column {
                Text(
                    text  = "Hola de nuevo",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.4f)
                )
                Text(
                    text  = "Carlos M.",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White
                )
                Spacer(Modifier.height(8.dp))
                // Racha
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = HazelOrange
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(Color(0xFFFFD0C5), shape = RoundedCornerShape(50))
                        )
                        Spacer(Modifier.width(5.dp))
                        Text(
                            "14 días seguidos",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White
                        )
                    }
                }
            }
        }

        Column(modifier = Modifier.padding(16.dp)) {
            // ── Stats row ─────────────────────────────────────────
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("47", "Visitas", Modifier.weight(1f))
                StatCard("14", "Racha",   Modifier.weight(1f))
                StatCard("3",  "Logros",  Modifier.weight(1f))
            }

            Spacer(Modifier.height(16.dp))

            Text(
                text  = "ACCIONES RÁPIDAS",
                style = MaterialTheme.typography.labelSmall,
                color = Color.Black.copy(alpha = 0.4f)
            )
            Spacer(Modifier.height(8.dp))

            // ── QR Entrada ────────────────────────────────────────
            QuickActionCard(
                title    = "Escanear entrada",
                subtitle = "Registra tu visita de hoy",
                onClick  = { navController.navigate(Screen.QrScanner.route) }
            )

            Spacer(Modifier.height(8.dp))

            // ── Rutinas ───────────────────────────────────────────
            QuickActionCard(
                title    = "Mis rutinas",
                subtitle = "Ver entrenamiento asignado",
                onClick  = { navController.navigate(Screen.ClientRoutines.route) }
            )
        }
    }
}

@Composable
fun StatCard(number: String, label: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape    = RoundedCornerShape(12.dp),
        colors   = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(number, style = MaterialTheme.typography.headlineMedium, color = HazelDark)
            Text(label,  style = MaterialTheme.typography.bodyMedium,    color = Color.Black.copy(alpha = 0.4f))
        }
    }
}

@Composable
fun QuickActionCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape  = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(HazelDark, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Icono QR placeholder — sustituir por Icon(Icons...)
                Text("QR", style = MaterialTheme.typography.labelSmall, color = HazelOrange)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title,    style = MaterialTheme.typography.titleMedium, color = HazelDark)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium,  color = Color.Black.copy(alpha = 0.4f))
            }
        }
    }
}
