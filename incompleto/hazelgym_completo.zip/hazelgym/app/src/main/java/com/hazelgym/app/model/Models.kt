package com.hazelgym.app.model

// ── Roles ─────────────────────────────────────────────────────────────────────
enum class UserRole { CLIENT, TRAINER, ADMIN }

// ── Usuario ───────────────────────────────────────────────────────────────────
data class User(
    val id       : String,
    val name     : String,
    val email    : String,
    val role     : UserRole,
    val active   : Boolean = true
)

// ── Máquina ───────────────────────────────────────────────────────────────────
data class Machine(
    val id           : String,
    val name         : String,
    val description  : String,
    val muscleGroup  : String,
    val instructions : List<String>,
    val tags         : List<String>  = emptyList(),
    val mediaUrl     : String?       = null,
    val level        : String        = "Medio",
    val safetyWarning: String?       = null,
    val status       : MachineStatus = MachineStatus.ACTIVE
)

enum class MachineStatus { ACTIVE, OUT_OF_SERVICE }

// ── QR ────────────────────────────────────────────────────────────────────────
enum class QrType { ENTRY, MACHINE, CLASS_SESSION }

data class QrCode(
    val id         : String,
    val type       : QrType,
    val referenceId: String    // id de máquina o sesión de clase
)

// ── Asistencia ────────────────────────────────────────────────────────────────
data class Attendance(
    val id       : String,
    val userId   : String,
    val qrId     : String,
    val dateTime : String   // ISO-8601
)

// ── Rutina ────────────────────────────────────────────────────────────────────
data class Routine(
    val id         : String,
    val name       : String,
    val description: String,
    val trainerId  : String
)

data class RoutineAssignment(
    val id       : String,
    val routineId: String,
    val clientId : String
)

// ── Clases ────────────────────────────────────────────────────────────────────
data class GymClass(
    val id         : String,
    val name       : String,
    val description: String,
    val duration   : Int,     // minutos
    val trainerId  : String,
    val active     : Boolean = true
)

data class ClassSession(
    val id        : String,
    val classId   : String,
    val date      : String,
    val startTime : String,
    val endTime   : String,
    val qrId      : String? = null
)

// ── Resultado escaneo QR ──────────────────────────────────────────────────────
sealed class QrScanResult {
    data class EntrySuccess(
        val attendance: Attendance,
        val totalVisits: Int,
        val streak     : Int
    ) : QrScanResult()

    data class MachineInfo(
        val machine: Machine
    ) : QrScanResult()

    data class ClassCheckin(
        val session     : ClassSession,
        val gymClass    : GymClass,
        val monthlyCount: Int
    ) : QrScanResult()

    data class Error(
        val reason: String
    ) : QrScanResult()
}

// ── Cuotas (informativo) ──────────────────────────────────────────────────────
data class MembershipPlan(
    val id         : String,
    val name       : String,
    val description: String,
    val price      : Double,
    val features   : List<String>
)
