package com.hazelgym.app.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ── Hazel Gym palette ─────────────────────────────────────────────────────────
val HazelOrange      = Color(0xFFFF4D2E)
val HazelOrangeLight = Color(0xFFFF6B50)
val HazelBlue        = Color(0xFF2266FF)
val HazelGreen       = Color(0xFF22CC66)
val HazelDark        = Color(0xFF0D0D14)
val HazelDarkSurface = Color(0xFF1C1C28)
val HazelError       = Color(0xFFE24B4A)

// ── Dark color scheme ─────────────────────────────────────────────────────────
private val DarkColorScheme = darkColorScheme(
    primary        = HazelOrange,
    onPrimary      = Color.White,
    secondary      = HazelBlue,
    onSecondary    = Color.White,
    tertiary       = HazelGreen,
    onTertiary     = HazelDark,
    background     = HazelDark,
    onBackground   = Color.White,
    surface        = HazelDarkSurface,
    onSurface      = Color.White,
    error          = HazelError,
    onError        = Color.White
)

// ── Light color scheme ────────────────────────────────────────────────────────
private val LightColorScheme = lightColorScheme(
    primary        = HazelOrange,
    onPrimary      = Color.White,
    secondary      = HazelBlue,
    onSecondary    = Color.White,
    tertiary       = HazelGreen,
    onTertiary     = Color.White,
    background     = Color(0xFFF5F4F0),
    onBackground   = HazelDark,
    surface        = Color.White,
    onSurface      = HazelDark,
    error          = HazelError,
    onError        = Color.White
)

@Composable
fun HazelGymTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography  = HazelTypography,
        content     = content
    )
}
