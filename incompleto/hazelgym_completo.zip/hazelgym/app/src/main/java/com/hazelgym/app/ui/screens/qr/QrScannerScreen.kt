package com.hazelgym.app.ui.screens.qr

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.hazelgym.app.ui.navigation.Screen
import com.hazelgym.app.ui.theme.*

enum class QrTab(val label: String) { ENTRY("Entrada"), MACHINE("Máquina"), CLASS("Clase") }

@Composable
fun QrScannerScreen(navController: NavController) {
    var selectedTab by remember { mutableStateOf(QrTab.ENTRY) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HazelDark)
    ) {
        // ── Top bar ───────────────────────────────────────────────
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { navController.popBackStack() }) {
                // Icon(Icons.Rounded.ArrowBack, ...)
                Box(
                    Modifier
                        .size(30.dp)
                        .background(HazelDarkSurface, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("←", color = Color.White, style = MaterialTheme.typography.titleMedium)
                }
            }
            Spacer(Modifier.width(8.dp))
            Text(
                "Escanear QR",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White
            )
        }

        // ── Tabs ─────────────────────────────────────────────────
        Row(
            modifier = Modifier.padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            QrTab.values().forEach { tab ->
                val selected = selectedTab == tab
                Surface(
                    modifier = Modifier
                        .weight(1f),
                    shape  = RoundedCornerShape(9.dp),
                    color  = if (selected) HazelOrange else HazelDarkSurface,
                    onClick = { selectedTab = tab }
                ) {
                    Text(
                        text  = tab.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) Color.White else Color.White.copy(alpha = 0.4f),
                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ── Visor QR ──────────────────────────────────────────────
        Box(
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .height(220.dp)
                .background(HazelDarkSurface, RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            // TODO: integrar CameraX + ML Kit BarcodeScanner aquí
            // Por ahora muestra un placeholder con botón de demo
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Cámara QR", color = Color.White.copy(alpha = 0.2f))
                Spacer(Modifier.height(8.dp))
                // Demo: simular escaneo exitoso
                TextButton(onClick = {
                    val type = selectedTab.name.lowercase()
                    val id   = "demo-id-001"
                    navController.navigate(Screen.QrResult.withArgs(type, id))
                }) {
                    Text("Simular escaneo", color = HazelOrange)
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        Text(
            text     = "Apunta al código QR para ${selectedTab.label.lowercase()}",
            style    = MaterialTheme.typography.bodyMedium,
            color    = Color.White.copy(alpha = 0.25f),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        Spacer(Modifier.height(16.dp))

        // ── Mini stats ───────────────────────────────────────────
        Row(
            modifier = Modifier.padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("47" to "Visitas", "14" to "Racha", "3" to "Logros").forEach { (num, lbl) ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(HazelDarkSurface, RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(num, style = MaterialTheme.typography.titleLarge, color = Color.White)
                        Text(lbl, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(0.3f))
                    }
                }
            }
        }
    }
}
