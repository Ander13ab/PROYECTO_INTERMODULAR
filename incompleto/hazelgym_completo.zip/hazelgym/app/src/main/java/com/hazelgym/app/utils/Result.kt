package com.hazelgym.app.utils

/**
 * Wrapper genérico para manejar el resultado de operaciones asíncronas.
 * Sustituye a los try/catch dispersos por el código.
 *
 * Uso:
 *   when (result) {
 *       is Result.Success -> { val user = result.data }
 *       is Result.Error   -> { val msg  = result.message }
 *       is Result.Loading -> { showSpinner() }
 *   }
 */
sealed class Result<out T> {
    data class Success<T>(val data: T)          : Result<T>()
    data class Error(val message: String)        : Result<Nothing>()
    object Loading                               : Result<Nothing>()
}
