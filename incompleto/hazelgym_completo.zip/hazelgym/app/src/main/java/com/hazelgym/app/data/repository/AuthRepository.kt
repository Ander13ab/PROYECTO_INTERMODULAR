package com.hazelgym.app.data.repository

import com.hazelgym.app.data.local.TokenDataStore
import com.hazelgym.app.data.remote.RetrofitClient
import com.hazelgym.app.data.remote.api.AuthApi
import com.hazelgym.app.data.remote.dto.LoginRequest
import com.hazelgym.app.model.User
import com.hazelgym.app.model.UserRole
import com.hazelgym.app.utils.Result

// ── Contrato ──────────────────────────────────────────────────────────────────
interface AuthRepository {
    suspend fun login(email: String, password: String): Result<User>
    suspend fun logout()
    suspend fun getCurrentUser(): Result<User>
}

// ── Implementación ────────────────────────────────────────────────────────────
class AuthRepositoryImpl(
    private val tokenDataStore: TokenDataStore
) : AuthRepository {

    private val api: AuthApi = RetrofitClient.instance.create(AuthApi::class.java)

    override suspend fun login(email: String, password: String): Result<User> {
        return try {
            val response = api.login(LoginRequest(email, password))

            if (response.isSuccessful) {
                val body = response.body()
                    ?: return Result.Error("Respuesta vacía del servidor")

                // Guardar token y datos en DataStore
                tokenDataStore.saveSession(
                    token    = body.token,
                    userId   = body.user.id,
                    userName = body.user.name,
                    role     = body.user.role
                )

                Result.Success(
                    User(
                        id    = body.user.id,
                        name  = body.user.name,
                        email = body.user.email,
                        role  = parseRole(body.user.role)
                    )
                )
            } else {
                val errorMsg = when (response.code()) {
                    401  -> "Email o contraseña incorrectos"
                    403  -> "Cuenta desactivada"
                    404  -> "Usuario no encontrado"
                    500  -> "Error del servidor, inténtalo más tarde"
                    else -> "Error ${response.code()}"
                }
                Result.Error(errorMsg)
            }
        } catch (e: java.net.UnknownHostException) {
            Result.Error("Sin conexión. Comprueba tu red.")
        } catch (e: java.net.SocketTimeoutException) {
            Result.Error("El servidor tardó demasiado en responder.")
        } catch (e: Exception) {
            Result.Error("Error inesperado: ${e.localizedMessage}")
        }
    }

    override suspend fun logout() {
        tokenDataStore.clearSession()
    }

    override suspend fun getCurrentUser(): Result<User> {
        return try {
            val response = api.getMe()
            if (response.isSuccessful) {
                val body = response.body()
                    ?: return Result.Error("Sin datos de usuario")
                Result.Success(
                    User(
                        id    = body.user.id,
                        name  = body.user.name,
                        email = body.user.email,
                        role  = parseRole(body.user.role)
                    )
                )
            } else {
                Result.Error("Sesión expirada")
            }
        } catch (e: Exception) {
            Result.Error(e.localizedMessage ?: "Error desconocido")
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private fun parseRole(role: String): UserRole = when (role.uppercase()) {
        "TRAINER" -> UserRole.TRAINER
        "ADMIN"   -> UserRole.ADMIN
        else      -> UserRole.CLIENT
    }
}
