package com.hazelgym.app.data.remote.api

import com.hazelgym.app.data.remote.dto.LoginRequest
import com.hazelgym.app.data.remote.dto.LoginResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface AuthApi {

    /**
     * POST /api/auth/login
     * Body: { "email": "...", "password": "..." }
     * Response: { "token": "eyJ...", "tokenType": "Bearer", "user": { ... } }
     *
     * Endpoint equivalente en Spring Boot:
     *   @PostMapping("/api/auth/login")
     *   fun login(@RequestBody request: LoginRequest): ResponseEntity<LoginResponse>
     */
    @POST("api/auth/login")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>

    /**
     * GET /api/auth/me
     * Header: Authorization: Bearer <token>
     * Devuelve el usuario autenticado — útil para validar el token al arrancar la app
     */
    @GET("api/auth/me")
    suspend fun getMe(): Response<LoginResponse>
}
