package com.hazelgym.app.data.remote

import com.hazelgym.app.data.local.TokenDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {

    // ⚠️ Cambia esta URL por la de tu servidor Spring Boot
    // Emulador Android → usa 10.0.2.2 en lugar de localhost
    // Dispositivo físico → usa la IP de tu máquina en la red local (ej: 192.168.1.X)
    private const val BASE_URL = "http://10.0.2.2:8080/"

    // Se inyecta desde el Application para acceder a DataStore
    lateinit var tokenDataStore: TokenDataStore

    // ── Interceptor JWT ───────────────────────────────────────────────────────
    private val authInterceptor = Interceptor { chain ->
        val token = runBlocking { tokenDataStore.getToken().first() }
        val request = if (!token.isNullOrBlank()) {
            chain.request().newBuilder()
                .addHeader("Authorization", "Bearer $token")
                .build()
        } else {
            chain.request()
        }
        chain.proceed(request)
    }

    // ── Logging (solo en debug) ───────────────────────────────────────────────
    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    // ── OkHttp ────────────────────────────────────────────────────────────────
    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(authInterceptor)
        .addInterceptor(loggingInterceptor)
        .build()

    // ── Retrofit ──────────────────────────────────────────────────────────────
    val instance: Retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
}
