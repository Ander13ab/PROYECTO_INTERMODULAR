package com.hazelgym.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.hazelgym.app.data.local.TokenDataStore
import com.hazelgym.app.ui.navigation.HazelNavGraph
import com.hazelgym.app.ui.navigation.Screen
import com.hazelgym.app.ui.theme.HazelGymTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            HazelGymTheme(darkTheme = true) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()
                    // LoginScreen arrancará y su ViewModel redirigirá
                    // automáticamente si hay token válido guardado
                    HazelNavGraph(
                        navController    = navController,
                        startDestination = Screen.Login.route
                    )
                }
            }
        }
    }
}
