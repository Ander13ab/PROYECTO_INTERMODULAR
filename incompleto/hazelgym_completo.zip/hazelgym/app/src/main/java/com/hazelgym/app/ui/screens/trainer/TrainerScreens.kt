package com.hazelgym.app.ui.screens.trainer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.hazelgym.app.ui.theme.HazelBlue
import com.hazelgym.app.ui.theme.HazelDark

@Composable
fun TrainerHomeScreen(navController: NavController) {
    // TODO: implementar pantalla completa de entrenador
    Column(
        Modifier.fillMaxSize().background(Color(0xFF0A1A4A)).padding(24.dp)
    ) {
        Text("Panel Entrenador", style = MaterialTheme.typography.headlineMedium, color = Color.White)
        Text("— Próximamente —", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(0.3f))
    }
}

@Composable
fun TrainerSessionsScreen(navController: NavController) {
    Column(
        Modifier.fillMaxSize().background(HazelDark).padding(24.dp)
    ) {
        Text("Sesiones de clase", style = MaterialTheme.typography.headlineMedium, color = Color.White)
    }
}
