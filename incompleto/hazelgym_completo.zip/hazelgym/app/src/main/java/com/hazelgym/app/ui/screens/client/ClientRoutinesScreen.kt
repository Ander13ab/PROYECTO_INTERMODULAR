package com.hazelgym.app.ui.screens.client

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun ClientRoutinesScreen(navController: NavController) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Mis rutinas", style = MaterialTheme.typography.headlineMedium)
        Text("— Próximamente —", style = MaterialTheme.typography.bodyMedium)
    }
}
