package com.hazelgym.app.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun AdminHomeScreen(navController: NavController) {
    Column(Modifier.fillMaxSize().background(Color(0xFF0D2010)).padding(24.dp)) {
        Text("Panel Admin", style = MaterialTheme.typography.headlineMedium, color = Color.White)
        Text("— Próximamente —", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(0.3f))
    }
}

@Composable
fun AdminUsersScreen(navController: NavController) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Gestión de usuarios", style = MaterialTheme.typography.headlineMedium)
    }
}

@Composable
fun AdminMachinesScreen(navController: NavController) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Gestión de máquinas", style = MaterialTheme.typography.headlineMedium)
    }
}

@Composable
fun AdminQrScreen(navController: NavController) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("Generar QR", style = MaterialTheme.typography.headlineMedium)
    }
}
