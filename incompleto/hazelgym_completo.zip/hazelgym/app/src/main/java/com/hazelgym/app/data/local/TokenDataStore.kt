package com.hazelgym.app.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// Extensión para crear el DataStore en el contexto de la aplicación
private val Context.dataStore by preferencesDataStore(name = "hazel_prefs")

class TokenDataStore(private val context: Context) {

    companion object {
        private val KEY_TOKEN     = stringPreferencesKey("jwt_token")
        private val KEY_USER_ID   = stringPreferencesKey("user_id")
        private val KEY_USER_NAME = stringPreferencesKey("user_name")
        private val KEY_USER_ROLE = stringPreferencesKey("user_role")
    }

    // ── Guardar token y datos básicos del usuario ─────────────────────────────
    suspend fun saveSession(token: String, userId: String, userName: String, role: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_TOKEN]     = token
            prefs[KEY_USER_ID]   = userId
            prefs[KEY_USER_NAME] = userName
            prefs[KEY_USER_ROLE] = role
        }
    }

    // ── Leer token ────────────────────────────────────────────────────────────
    fun getToken(): Flow<String?> =
        context.dataStore.data.map { it[KEY_TOKEN] }

    // ── Leer rol (para decidir a qué Home navegar) ────────────────────────────
    fun getUserRole(): Flow<String?> =
        context.dataStore.data.map { it[KEY_USER_ROLE] }

    // ── Leer nombre de usuario ────────────────────────────────────────────────
    fun getUserName(): Flow<String?> =
        context.dataStore.data.map { it[KEY_USER_NAME] }

    // ── Cerrar sesión: borra todo ─────────────────────────────────────────────
    suspend fun clearSession() {
        context.dataStore.edit { it.clear() }
    }

    // ── ¿Hay sesión activa? ───────────────────────────────────────────────────
    fun isLoggedIn(): Flow<Boolean> =
        getToken().map { !it.isNullOrBlank() }
}
