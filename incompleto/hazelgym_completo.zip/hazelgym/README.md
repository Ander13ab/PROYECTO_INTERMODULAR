# Hazel Gym — Android App

Aplicación de gestión de gimnasio con roles diferenciados (cliente, entrenador, administrador) y sistema de códigos QR.

---

## Estructura del proyecto

```
app/src/main/java/com/hazelgym/app/
│
├── MainActivity.kt                        ← Entrada principal
│
├── ui/
│   ├── navigation/
│   │   └── NavGraph.kt                    ← Rutas y NavHost
│   │
│   ├── theme/
│   │   ├── Theme.kt                       ← Colores y esquema
│   │   └── Typography.kt                  ← Tipografía
│   │
│   ├── components/                        ← Componentes reutilizables (próximo)
│   │
│   └── screens/
│       ├── auth/
│       │   └── LoginScreen.kt
│       ├── client/
│       │   ├── ClientHomeScreen.kt
│       │   └── ClientRoutinesScreen.kt    ← stub
│       ├── trainer/
│       │   └── TrainerScreens.kt          ← stub
│       ├── admin/
│       │   └── AdminScreens.kt            ← stub
│       ├── qr/
│       │   ├── QrScannerScreen.kt
│       │   └── QrResultScreen.kt          ← Entrada / Máquina / Clase / Error
│       └── machines/
│           └── MachineDetailScreen.kt     ← stub
│
├── viewmodel/                             ← ViewModels (próximo)
│
├── model/
│   └── Models.kt                          ← Entidades del dominio
│
├── data/
│   ├── repository/                        ← Contratos de repositorio (próximo)
│   ├── remote/
│   │   ├── api/                           ← Interfaces Retrofit (próximo)
│   │   └── dto/                           ← Data Transfer Objects (próximo)
│   └── local/                             ← Room / DataStore (próximo)
│
├── di/                                    ← Hilt / inyección (próximo)
└── utils/                                 ← Utilidades (próximo)
```

---

## Conectar con GitHub

### Si el repositorio ya existe y está vacío

```bash
# 1. Clona el repositorio
git clone https://github.com/Ander13ab/hazelgym.git

# 2. Copia estos archivos dentro de la carpeta clonada
#    (o crea el proyecto de Android Studio dentro de esa carpeta)

# 3. Haz el primer commit
cd hazelgym
git add .
git commit -m "feat: estructura inicial Hazel Gym"
git push origin main
```

### Si ya tienes el proyecto creado en Android Studio

```bash
# Dentro de la carpeta raíz del proyecto Android
git init
git remote add origin https://github.com/Ander13ab/hazelgym.git
git add .
git commit -m "feat: estructura inicial Hazel Gym"
git push -u origin main
```

### Conectar Android Studio al repositorio existente

1. **File → New → Project from Version Control**
2. Pega la URL: `https://github.com/Ander13ab/hazelgym.git`
3. Elige la carpeta local y pulsa **Clone**
4. Android Studio lo abrirá automáticamente

### Para commits del día a día (desde Android Studio)

- Panel **Git** (abajo a la izquierda) o `Ctrl+K` para hacer commit
- `Ctrl+Shift+K` para hacer push
- O desde terminal: `git add . && git commit -m "..." && git push`

---

## Paleta de colores

| Color        | Hex       | Uso                     |
|--------------|-----------|-------------------------|
| HazelOrange  | #FF4D2E   | Cliente / acción primaria |
| HazelBlue    | #2266FF   | Entrenador               |
| HazelGreen   | #22CC66   | Admin / éxito            |
| HazelDark    | #0D0D14   | Fondos oscuros           |
| HazelError   | #E24B4A   | Errores                  |

---

## Dependencias principales

| Librería               | Uso                              |
|------------------------|----------------------------------|
| Compose BOM 2024.12    | UI completa                      |
| Navigation Compose 2.8 | Navegación entre pantallas       |
| Lifecycle ViewModel    | Gestión de estado                |
| Retrofit 2.11          | Llamadas a API REST              |
| Coil 2.7               | Carga de imágenes                |
| CameraX + ML Kit       | Escáner QR (comentado, activar)  |

---

## Próximos pasos

- [ ] Implementar `AuthViewModel` con login real
- [ ] Activar CameraX + ML Kit para el escáner QR
- [ ] Completar pantallas de Entrenador y Admin
- [ ] Crear repositorios de datos (API REST / Room)
- [ ] Pantalla de detalle de máquina completa
- [ ] Pantalla de rutinas del cliente
